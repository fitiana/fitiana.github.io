<?php

add_shortcode("nasa_search", "nasa_sc_search");
function nasa_sc_search() {
    return function_exists('get_product_search_form') ? get_product_search_form() : '';
}
